<?php 
/*
Template Name: page template
*/

get_header();?>
<section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php the_permalink();?>">home</a></li> / 
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

<section class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h4><?php the_title();?></h4>
                <?php the_content();?>

            </div>
            <div class="col-md-4">
            <?php 
                    if(is_active_sidebar('sidebar-1')){
                        dynamic_sidebar('sidebar-1');
                    }
                    
                    ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer();?>
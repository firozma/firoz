<?php 

get_header();
?>

 <!-- Breadcumb Area Start Here -->
 <section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <div class="search-page">
                    <h1>Page not found !!</h1>
                    </div>
                
                </div>
            </div>
        </div>
    </section>
   

<?php get_footer();?>
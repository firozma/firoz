
<?php 
    require_once('inc/custom-post.php');
    require_once('inc/option-page.php');
    require_once('inc/register-sidebar.php');


function halim_template_bootstrap(){
    load_theme_textdomain('halim', get_template_directory() . '/languages');

    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo', array(
        'height' => 480,
        'width'  => 720,
    ) );
    add_theme_support( 'post-thumbnails',array('post','gallery','sliders','services','teams','testimonials','portfolio') );
    add_theme_support( 'custom-background' );

    	
    register_nav_menus( array(
         'main-menu' => __('Maim Mune','halim'),
         'footer-menu'=>__('Footer Menu','halim') 
         
         ) );
    	
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' ) );


}


add_action('after_setup_theme','halim_template_bootstrap');

function halim_theme_styles(){

    wp_enqueue_style('main-style',get_stylesheet_uri());
    wp_enqueue_style('bootstrap-css',get_theme_file_uri().'/assets/css/bootstrap.min.css');
    wp_enqueue_style('awesome-css',get_theme_file_uri().'/assets/css/font-awesome.min.css');
    wp_enqueue_style('carousel-css',get_theme_file_uri().'/assets/css/owl.carousel.min.css');
    wp_enqueue_style('theme-css',get_theme_file_uri().'/assets/css/owl.theme.default.css');
    wp_enqueue_style('style-css',get_theme_file_uri().'/assets/css/style.css');
    wp_enqueue_style('responsive-css',get_theme_file_uri().'/assets/css/responsive.css');

    wp_enqueue_script('jquery-js',get_theme_file_uri().'/assets/js/jquery.min.js',array('jquery'),time(),true);
    wp_enqueue_script('popper-js',get_theme_file_uri().'/assets/js/popper.min.js',array('jquery'),time(),true);
    wp_enqueue_script('bootstrap-js',get_theme_file_uri().'/assets/js/bootstrap.min.js',array('jquery'),time(),true);
    wp_enqueue_script('carousel-js',get_theme_file_uri().'/assets/js/owl.carousel.min.js',array('jquery'),time(),true);
    wp_enqueue_script('waypoint-js',get_theme_file_uri().'/assets/js/waypoint.min.js',array('jquery'),time(),true);
    wp_enqueue_script('counterup-js',get_theme_file_uri().'/assets/js/counterup.min.js',array('jquery'),time(),true);
    wp_enqueue_script('isotope-js',get_theme_file_uri().'/assets/js/isotope.min.js',array('jquery'),time(),true);
    wp_enqueue_script('main-js',get_theme_file_uri().'/assets/js/main.js',array('jquery'),time(),true);

}

add_action('wp_enqueue_scripts','halim_theme_styles');







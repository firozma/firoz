<?php get_header();?>

<section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php echo site_url();?>">home</a></li> /
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="portfolio-header p5-2">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="portfolio-section">
                        <h2 class="py-2"><?php the_title();?></h2>
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                        <?php the_content();?>
                    </div>
                    <div class="row">
                        <h2>Gallery Image</h2>
                        <?php 
                        
                        if($images=get_field('gallery_image')){
                            $images=get_field('gallery_image');
                            foreach($images as $image){
                            ?>
                                  <div class="col-xl-4">
                                     <div class="portfolio-gallery  py-3">
                                         <img src="<?php echo $image['url'];?>" alt="">
                                     </div>
                                     </div>
                            <?php
                            }

                        }
                             ?>
                        
                       
                        
                       
                    </div>
                    <div class="video-gallery">
                    <h2>Gallery video</h2>
                        <?php echo the_field('video');?>
                    </div>

                </div>
               <div class="col-xl-4">
                   <div class="cloud-tag">
                   <h2 class="py-2">Tecnology used </h2>
                       <ul>
                           <?php 
                        if($features= get_field('feature')){
                            $features= get_field('feature');
                            foreach($features as $feature){
                             ?>
                             <li><i class="fa fa-arrow-right"></i> <a href="#"> <?php echo $feature['feature_text'];?></a></li>
                       
                             <?php
                            }
                             }
                            ?>
                        
                         
                       </ul>
                   </div>
               </div>
            </div>
        </div>

    </section>




<?php get_footer();?>
<?php 
/*
    Template Name: Gallery page
*/

get_header();?>

    <!-- Breadcumb Area Start Here -->
    <section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php echo site_url();?>">home</a></li> /
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcumb Area End Here -->

    <section class="gallery-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <?php 
                $args= array(
                    'post_type'=>'gallery',
                    'posts_per_page'=>10

                );
                $query= new WP_Query($args);
                while($query->have_posts()){
                    $query->the_post();
                    ?>
                     <div class="col-md-4">
                    <div class="single-gallery">
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                        <div class="gallery-overlay">
                            <a href="<?php the_field('image');?>" class="gallery"><i class="fas fa-plus"></i></a>
                            <h4><?php the_title();?></h4>
                        </div>
                    </div>
                </div>
                    <?php
                }
                ?>
               
                
            </div>
        </div>
    </section>

    <!-- CTA Area Start Here -->
    <section class="cta-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4>best solution for your business </h4>
                    <p>the can be used on larger scale projectss as well as small scale projectss</p>
                </div>
                <div class="col-md-6 text-center">
                    <a href="" class="box-btn">contact us <i class="fas fa-angle-double-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Area End Here -->

   <?php get_footer();?>
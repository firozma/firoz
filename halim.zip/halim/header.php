<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <title><?php wp_title(); ?></title>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
        <?php wp_head(); ?>
    </head>
   <body <?php body_class();?>>
	   <!-- Preloader Area Start
      <div class="preloader flex-center">
         <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
         </div>
      </div>-->
      <!-- Preloader Area End -->
	   <section class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<div class="header-left">
                    
							<a href=""><i class="fa <?php the_field('header_icons','option');?>"></i> <?php  the_field('header','option');?></a>
							<a href=""><i class="fa <?php the_field('phone_icons','option');?>"></i><?php   the_field('phone_number','option');?></a>
						</div>
					</div>
					<div class="col-md-6 col-sm-12 text-right">
						<div class="header-social">
                     <?php 
                     $social_icons=get_field('social_icons','option');

                     foreach( $social_icons as $social_icon){
                        ?>
                        <a href="<?php echo $social_icon['link'];?>"><i class="fa <?php echo $social_icon['icon'];?>"></i></a>
                        <?php

                     }
                     
                     ?>
							
						</div>
					</div>
				</div>
			</div>
	   </section>
      <!-- Header Area Start -->
      <header class="header-area header-fixed">
         <div class="container">
            <div class="row">
               <div class="col-xl-12">
                  <nav class="navbar navbar-expand-md navbar-light">
                     <a class="navbar-brand" href="#">halim</a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse ml-auto mainmenu justify-content-end" id="navbarNav">
                        
                        <?php 
                        wp_nav_menu(array(
                            'theme_location'=>'main-menu',
                            'menu_class'=>'navbar-nav ml-auto'

                        ));
                        
                        ?>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
      </header>
      <!-- Header Area Start -->
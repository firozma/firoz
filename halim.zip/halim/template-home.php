<?php 

/*
Template Name: Home page
*/

get_header();?>

    <!-- Slider Area Start Here -->
    <section class="slider-area">
        <div class="sliders owl-carousel">
            <?php 
            if( class_exists('ACF')){
            $args=array(
                'post_type'=>'sliders',
                'posts_per_page'=>3



            );
            $uqery=new WP_Query($args);

            while($uqery->have_posts()){

                $uqery->the_post();
                ?>
                <div class="single-slide bg" style="background-image: url('<?php echo get_the_post_thumbnail_url();?>');">
                <div class="container">
                    <div class="row">
                        <div class="col-xxl-12">
                            <div class="slide-content">
                                <h4><?php the_field('sub_title');?></h4>
                                <h1><?php the_title();?></h1>
                                <?php the_content();?>
                                <a href="<?php the_field('url');?>" class="box-btn"><?php the_field('but_title');?> <i class="fas fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <?php
            }
        }
            ?>
            
           
        </div>
    </section>
    <!-- Slider Area End Here -->

    <!-- About Area Start Here -->
    <div class="section about-area pt-100 pb-100">
        <div class="container">
            <div class="row section-title align-items-center">
                <div class="col-md-6 text-md-end text-sm-center">
                    <?php 
                    $about_section= get_field('about_title','option');
                    
                  
                    ?>
                    <span><?php echo $about_section['sub_title'];?></span>
                    <h4><?php echo $about_section['title'];?></h4>
                </div>
                <div class="col-md-6">
                    <p><?php echo $about_section['description'];?></p>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-7 col-lg-6">
                    <div class="about-content">

                    <?php 
                        $about_halim= get_field('about_halim','option');
                    ?>
                        <h4><?php echo $about_halim['title'];?></h4>
                        <p>
                        <?php echo $about_halim['description'];?>
                        </P>
                        <a href="<?php echo $about_halim['bnt_url'];?>" class="box-btn"><?php echo $about_halim['btn_title'];?><i class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 mt-5 mt-lg-0">
                    <?php 
                        $amis= get_field('ami','option');
                        foreach($amis as $ami){

                            ?>
                                 <div class="single-about">
                        <div class="icon">
                            <i class="fas <?php echo $ami['icon'];?>"></i>
                        </div>
                        <div>
                            <h4><?php echo $ami['title'];?></h4>
                            <p><?php echo $ami['description'];?></p>
                        </div>
                    </div>
                            <?php
                        }
                    ?>
                   
                    
                </div>
            </div>
        </div>
    </div>
    <!-- About Area End Here -->

    <!-- Skill Area Start Here -->
    <section class="skill-area bg pt-100 pb-100" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/bg-skill.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="skill-title">
                        <h4>faq</h4>
<!---accordian --->                        
                    </div>
                    <div class="skill-accordion">
                        <div class="accordion" id="accordionExample">
                        <?php 
                            $faq_sections=get_field('faq_section', 'option');
                            $i = 0;
                            foreach($faq_sections as $faq_section){
                                $i++;
                                ?>
                                 <div class="accordion-item">
                              <h2 class="accordion-header" id="heading<?php echo $i;?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i;?>" aria-expanded="true" aria-controls="collapse<?php echo $i;?>">
                                    <?php echo $faq_section['title'];?>
                                </button>
                              </h2>
                              <div id="collapse<?php echo $i;?>" class="accordion-collapse collapse <?php if($i==1){echo 'show';}?> " aria-labelledby="heading<?php echo $i;?>" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                  <?php echo $faq_section['description'];?>
                                </div>
                              </div>
                            </div>
                                <?php
                            }
                                ?>
                           
                            
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 mt-5 mt-xl-0">
                    <div class="skill-title">
                        <h4><?php the_field('faq_title','option');?></h4>
                    </div>
                    <?php 
                    $faq_skills=get_field('faq_skill','option');
                    foreach( $faq_skills as $faq_skill){

                        ?>
                        <div class="single-progress">
                        <h4><?php echo $faq_skill['title'];?></h4>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" style="width:<?php echo $faq_skill['skill_number'];?>%;" aria-valuenow="<?php echo $faq_skill['skill_number'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $faq_skill['skill_number'];?>%</div>
                        </div>
                    </div>
                        <?php
                    }
                    
                    ?>
                    
                   
                </div>
            </div>
        </div>
    </section>
    <!-- Skill Area End Here -->

    <!-- Services Area Start Here -->
    <section class="services-area pt-100 pb-100">
        <div class="container">
            <div class="row section-title align-items-center">
                <div class="col-md-6 text-md-end text-sm-center">
                    <span>who we are?</span>
                    <h4>our services</h4>
                </div>
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo vitae dicta, hic sapiente sit perspiciatis modi officiis inventore architecto minima.</p>
                </div>
            </div>
            <div class="row">

            <?php 
                $args=array(
                    'post_type'=>'services',
                    'posts_per_page'=>6
                );
                $query= new WP_Query($args);
                while($query->have_posts()){

                    $query->the_post();
                    ?>
                        <div class="col-xl-4 col-lg-6">
                    <div class="single-service">
                        <i class="<?php the_field('icons');?>"></i>
                        <h4><?php the_title();?></h4>
                        <p><?php the_content();?></p>
                        <a href="#"><?php the_field('btn');?></a>
                    </div>
                </div>
                    <?php
                }
            ?>
                
               
            </div>
        </div>
    </section>
    <!-- Services Area End Here -->

    <!-- Counter Area Start Here -->
    <section class="counter-area">
        <div class="container-fluid g-0">
            <div class="row g-0">
                <?php 
                 $args=array(
                    'post_type'=>'counters',
                    'posts_per_page'=>-1
                );
                $query= new WP_Query($args);
                while($query->have_posts()){
                    $query->the_post();
                    ?>
                        <div class="col-xxl-3 col-sm-6">
                    <div class="single-counter">
                        <i class="<?php echo the_field('icon')?>"></i>
                        <h4><span class="counter"><?php echo the_field('counter_number');?></span><?php the_title();?></h4>
                    </div>
                </div>
                    <?php
                }
                
                ?>
                
                
            </div>
        </div>
    </section>
    <!-- Counter Area End Here -->

    <!-- Team Area Start Here -->
    <section class="team-area pt-100 pb-100">
        <div class="container">
            <div class="row section-title align-items-center">
                <div class="col-md-6 text-md-end text-sm-center">
                    <span>who we are?</span>
                    <h4>creative team</h4>
                </div>
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo vitae dicta, hic sapiente sit perspiciatis modi officiis inventore architecto minima.</p>
                </div>
            </div>
            <div class="row">
                <?php 
                $args= array(
                    'post_type'=>'teams',
                    'posts_per_page'=>3
                );
                $query=new WP_Query($args);
                while($query->have_posts()){
                    $query->the_post();
                    ?>
                        <div class="col-md-4">
                    <div class="single-team">
                        <?php echo  get_the_post_thumbnail();?>
                        <div class="team-content">
                            <h4><?php echo the_field('name');?><span><?php the_title();?></span></h4>
                            <div class="team-con">
                                <?php 
                                $icons= get_field('icons');
                                foreach($icons as $icon){
                                        ?>
                                        <a href=""><i class="fa <?php echo $icon['icon'];?>"></i></a>
                                        <?php

                                }
                                ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
                    <?php
                }
                ?>
                
               
            </div>
        </div>
    </section>
    <!-- Team Area End Here -->

    <!-- Testimonials Area Start Here -->
    <section class="testimonials-area pt-100 pb-100 bg" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/images/testi_back.jpg');">
        <div class="container-fluid">
            <div class="row section-title align-items-center">
                <div class="col-md-6 text-md-end text-sm-center">
                    <span>who we are?</span>
                    <h4>what clients say?</h4>
                </div>
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo vitae dicta, hic sapiente sit perspiciatis modi officiis inventore architecto minima.</p>
                </div>
            </div>
            <div class="row">
                <div class="testimonials owl-carousel">
                    <?php 
                    $args= array(

                        'post_type'=>'testimonials',
                        'posts_per_page'=>4
                    );
                    $query= new WP_Query($args);
                    while($query->have_posts()){
                        $query->the_post();
                        ?>

                    <div class="single-testimonial">
                        <div>
                       <?php the_post_thumbnail();?>
                    </div>
                       <?php the_content();?>
                        <h4>john doe <span><?php the_title();?></span></h4>
                    </div>

                        <?php
                    }
                    ?>
                    
                    
                  
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonials Area End Here -->

    <!-- Blog Area Start Here -->
    <section class="blog-area pt-100 pb-100">
        <div class="container">
            <div class="row section-title align-items-center">
                <div class="col-md-6 text-md-end text-sm-center">
                    <span>who we are?</span>
                    <h4>what clients say?</h4>
                </div>
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo vitae dicta, hic sapiente sit perspiciatis modi officiis inventore architecto minima.</p>
                </div>
            </div>
            <div class="row">
                <?php 
                $args=array(
                    'post_type'=>'post',
                    'posts_per_page'=>3
                );
                $query=new WP_Query($args);
                while($query->have_posts()){
                    $query->the_post();
                    ?>
                          <div class="col-md-4">
                    <div class="single-blog">
                       <?php the_post_thumbnail();?>
                    <div class="blog-content">
                            <div class="blog-title">
                                <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                            </div>
                            <div class="blog-meta">
                                <a href=""><?php echo get_the_date();?></a>
                                <a href=""><?php echo get_the_author_posts_link();?></a>
                            </div>
                           <?php the_content();?>
                            <a href="<?php the_permalink();?>" class="box-btn">read more <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
                    <?php
                }
                
                ?>
              
               
            </div>
        </div>
    </section>
    <!-- Blog Area End Here -->

    <!-- CTA Area Start Here -->
    <section class="cta-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <?php
                     if(class_exists('ACF')){
                        $ctp_sections= get_field('ctp_sections','option');
                     }
                    

                    ?>
                    <h4><?php echo $ctp_sections['title'];?></h4>
                    <p><?php echo $ctp_sections['description'];?></p>
                </div>
                <div class="col-md-6 text-center">
                    <a href="<?php echo $ctp_sections['url'];?>" class="box-btn"><?php echo $ctp_sections['ctp_btn_title'];?><i class="fas fa-angle-double-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Area End Here -->

    <?php get_footer();?>
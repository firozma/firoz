<?php 

function halim_theme_slug_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'halim' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<div class="sidebar">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'footer one', 'halim' ),
        'id'            => 'footer-1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<div class="single-footer">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4">',
        'after_title'   => '</h4>',
    ) );
    register_sidebar( array(
        'name'          => __( 'footer Two', 'halim' ),
        'id'            => 'footer-2',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<div class="single-footer">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'halim_theme_slug_widgets_init' );


//comments form design 


function move_comment_field( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
}

add_filter( 'comment_form_fields', 'move_comment_field' );





//placeholder 

/**
 * Change default fields, add placeholder and change type attributes.
 *
 * @param  array $fields
 * @return array
 */
function halim_comment_placeholders( $fields )
{
    $fields['author'] = str_replace(
        '<input',
        '<input placeholder="'
        
            . _x(
                'First Name',
                'halim'
                )
            . '"',
        $fields['author']
    );
    $fields['email'] = str_replace(
        '<input id="email" name="email" type="email"',
        '<input placeholder="'
        
            . _x(
                'Your Email',
                'halim'
                )
            . '" type="email" name="email"',
        $fields['email']
    );
    $fields['url'] = str_replace(
        '<input id="url" name="url" type="url"',
        '<input placeholder="'
        
            . _x(
                'Your Url',
                'halim'
                )
            . '" type="url" name="url"',
        $fields['url']
    );

  
   
    return $fields;
}
add_filter( 'comment_form_default_fields', 'halim_comment_placeholders' );

//only for textarea 

function placeholder_comment_form_field($fields) {
    $replace_comment = __('Your Comment', 'generatepress');
     
    $fields['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun' ) .
    '</label><textarea id="comment" name="comment" cols="45" rows="8" placeholder="'.$replace_comment.'" aria-required="true"></textarea></p>';
    
    return $fields;
 }
add_filter( 'comment_form_defaults', 'placeholder_comment_form_field', 20 );
<?php 


function halim_custom_post_type(){

    register_post_type('sliders',
        array(
            'labels'      => array(
                'name'          => __('sliders', 'halim'),
                'singular_name' => __('Sliders', 'halim'),
            ),
                'public'      => true,
                'show_ui' => true,
                'supports' => array( 'title', 'editor',  'thumbnail', 'custom-fields' ),
                'show_in_rest'       => true
    )
        );


        register_post_type('services',
        
        array(

            'labels'=>array(
                'name'=>__('Services','halim'),
                'singular_name'=>__('Services', 'halim')

            ),
            'public'=>true,
            'show_ui'=>true,
            'supports'=>array('title','editor','custom-fields','thumbnail'),
            'show_in_rest'       => true

        )
    
    );
    
    register_post_type('counters',
        
    array(

        'labels'=>array(
            'name'=>__('counters','halim'),
            'singular_name'=>__('counters', 'halim')

        ),
        'public'=>true,
        'show_ui'=>true,
        'supports'=>array('title','custom-fields'),
        'show_in_rest'       => true

    )

);


register_post_type('teams',
        
array(

    'labels'=>array(
        'name'=>__('teams','halim'),
        'singular_name'=>__('teams', 'halim')

    ),
    'public'=>true,
    'show_ui'=>true,
    'supports'=>array('title','custom-fields','thumbnail'),
    'show_in_rest'       => true

));

register_post_type('testimonials',
        
array(

    'labels'=>array(
        'name'=>__('testimonials','halim'),
        'singular_name'=>__('testimonials', 'halim')

    ),
    'public'=>true,
    'show_ui'=>true,
    'supports'=>array('title','custom-fields','editor','thumbnail'),
    'show_in_rest'       => true

));
register_post_type('gallery',
        
array(

    'labels'=>array(
        'name'=>__('gallerys','halim'),
        'singular_name'=>__('gallery', 'halim')

    ),
    'public'=>true,
    'show_ui'=>true,
    'supports'=>array('title','thumbnail'),
    'show_in_rest'       => true

));
// isotop . portfolio 
register_post_type('portfolio',
        
array(

    'labels'=>array(
        'name'=>__('portfolios','halim'),
        'singular_name'=>__('portfolio', 'halim')

    ),
    'public'=>true,
    'show_ui'=>true,
    'supports'=>array('title','custom-fields','editor','thumbnail'),
    'show_in_rest'       => true

));
register_taxonomy('portfolio-cat','portfolio',array(
    'labels'=>array(
        'name'=>__('categories','halim'),
        'singular_name'=>__('category','halim'),

    ),
    'hierarchical'=>true,
    'show_admin_column'=>true


));

    
}

add_action('init', 'halim_custom_post_type');


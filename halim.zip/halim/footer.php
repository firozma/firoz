  <!-- Footer Area End -->
  <footer class="footer-area bg pt-50 pb-50">
         <div class="container">
            <div class="row">
               <div class="col-lg-3 col-md-6">
                  <div class="single-footer footer-logo">
                     <h3><?php the_field('footer_title','option');?></h3>
                     <p><?php the_field('footer_decription','option');?></p>
                  </div>
               </div>
               <div class="col-lg-2 col-md-6">
               <?php 
                    if(is_active_sidebar('footer-1')){
                        dynamic_sidebar('footer-1');
                    }
                    
                    ?>
               </div>
               <div class="col-lg-4 col-md-6">
               <?php 
                    if(is_active_sidebar('footer-2')){
                        dynamic_sidebar('footer-2');
                    }
                    
                    ?>
               </div>
               <div class="col-lg-3 col-md-6">
                  <div class="single-footer">
                     <div class="post-img">
                     <h4>flickr</h4>
                     <?php 
                     if( class_exists('ACF')){ 
                     $fliker_imgs= get_field('fliker_img','option');
                     foreach($fliker_imgs as $fliker_img){
                        
                        ?>
                        <a href="#">
                     <img src="<?php echo $fliker_img['img']['url']; ?>" alt="" />
                     </a>
                        <?php
                     }
                  }
                     ?>
                     
                     
                     </div>
                   
                  </div>
               </div>
            </div>
            <div class="row copyright pt-5">
               <div class="col-md-6">
                  <p>&copy; <?php the_field('footer_reserve','option');?></p>
               </div>
               <div class="col-md-6 text-right ">
                  <ul>
                     <?php 
                     $footer_icons = get_field('footer_icons','option');
                     foreach($footer_icons as $footer_icon){
                        ?>
                        <li><a href="<?php echo $footer_icon['url'];?>"><i class="fa <?php echo $footer_icon['icon'];?>"></i></a></li>
                        <?php
                     }
                     ?>
                     
                  </ul>
               </div>
            </div>
         </div>
      </footer>
      <?php wp_footer();?>
   </body>
</html>
<?php 
    get_header();
?>

    <!-- Breadcumb Area Start Here -->
    <section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <h4><?php echo single_post_title();?></h4>
                    <ul>
                        <li><a href="<?php echo site_url();?>">home</a></li> / 
                        <li><?php echo single_post_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcumb Area End Here -->

    <section class="blog-page-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <?php 
                $args=array(
                    'post_type'=>'post',
                    'posts_per_page'=>10
                );
                $query=new WP_Query($args);
                while($query->have_posts()){
                    $query->the_post();
                    ?>
                     <div class="col-md-4">
                    <div class="single-blog">
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                        <div class="blog-content">
                            <div class="blog-title">
                                <h4><a href=""><?php the_title();?></a></h4>
                            </div>
                            <div class="blog-meta">
                                <a href=""><?php echo get_the_date();?></a>
                                <?php the_category();?>
                            </div>
                            <?php the_excerpt();?>
                           <a href="<?php the_permalink();?>" class="box-btn">read more <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
                    <?php
                }
                
                ?>
               
                
            </div>
            <div class="row">
                <div class="col-xxl-12">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                          <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                          </li>
                          <li class="page-item"><a class="page-link" href="#">1</a></li>
                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                          <li class="page-item"><a class="page-link" href="#">3</a></li>
                          <li class="page-item">
                            <a class="page-link" href="#">Next</a>
                          </li>
                        </ul>
                      </nav>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Area Start Here -->
    <section class="cta-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4>best solution for your business </h4>
                    <p>the can be used on larger scale projectss as well as small scale projectss</p>
                </div>
                <div class="col-md-6 text-center">
                    <a href="" class="box-btn">contact us <i class="fas fa-angle-double-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Area End Here -->

    <?php get_footer();?>
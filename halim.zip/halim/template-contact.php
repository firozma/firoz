<?php 

/*
Template Name: contact page
*/
get_header();?>

    <!-- Breadcumb Area Start Here -->
    <section class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 text-center">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php the_permalink();?>">home</a></li> / 
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcumb Area End Here -->

    <!-- Contact Area Start Here -->
    <section class="contact-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-xxl-9 col-md-12 mx-auto">
                    <div class="row">

                    <?php 
                    if(class_exists('ACF')){
                    $contact_sections= get_field('contact_section','option');
                    foreach($contact_sections as $contact_section){
                        ?>
                        <div class="col-md-4">
                            <div class="contact-address">
                                <i class="fas <?php echo $contact_section['icons'];?>"></i>
                                <h4><?php echo $contact_section['title'];?> <span><?php echo $contact_section['descripts'];?></span></h4>
                            </div>
                        </div>
                        <?php

                    }
                }
                    
                    ?>
                        
                  </div>
                    <div class="row">
                        <div class="col-md-7">
                            <div class="contact-form">
                                <?php echo do_shortcode('[contact-form-7 id="272" title="contact from"]');?>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="contact-map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3618.325587665938!2d91.86642381497002!3d24.920975984025414!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3750551e7da58bcd%3A0x7cd35cba3faa14e7!2sSylhet%20International%20Cricket%20Stadium!5e0!3m2!1sen!2sbd!4v1618568732799!5m2!1sen!2sbd" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Area End Here -->

    <!-- CTA Area Start Here -->
    <section class="cta-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4>best solution for your business </h4>
                    <p>the can be used on larger scale projectss as well as small scale projectss</p>
                </div>
                <div class="col-md-6 text-center">
                    <a href="" class="box-btn">contact us <i class="fas fa-angle-double-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA Area End Here -->

   <?php get_footer();?>